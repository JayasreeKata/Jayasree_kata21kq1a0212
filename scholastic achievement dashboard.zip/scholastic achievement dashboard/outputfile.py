Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:\Users\jaysr\AppData\Local\Programs\Python\Python312\jayasree.py

= RESTART: C:\Users\jaysr\AppData\Local\Programs\Python\Python312\jayasree.py
20
enter name:jaya
enter roll_number:201
enter marks:78 76 56 78
enter name:anju
enter roll_number:202
enter marks:98 76 54 43
enter name:likki
enter roll_number:203
enter marks:65 34 35 67
enter name:subbu
enter roll_number:204
enter marks:45 67 89 65
enter name:nanii
enter roll_number:205
enter marks:67 87 89 76
enter name:keerthi
enter roll_number:206
enter marks:43 25 67 89
enter name:poori
enter roll_number:207
enter marks:78 76 65 90
enter name:janu
enter roll_number:208
enter marks:67 89 54 43
enter name:navya
enter roll_number:209
enter marks:56 78 43 76
enter name:kavya
enter roll_number:210
enter marks:89 76 34 21
enter name:kanna
enter roll_number:211
enter marks:56 56 38 90
enter name:lukky
enter roll_number:212
enter marks:76 45 34 23
enter name:rani
enter roll_number:213
enter marks:56 78 87 34
enter name:pooji
enter roll_number:214
enter marks:90 87 56 34
enter name:swapna
enter roll_number:215
enter marks:78 56 43 89
enter name:uma
enter roll_number:216
enter marks:56 78 45 23
enter name:remo
enter roll_number:217
enter marks:67 54 43 78
enter name:ramya
enter roll_number:218
enter marks:68 98 65 43
enter name:lithu
enter roll_number:219
enter marks:98 76 45 90
enter name:divya
enter roll_number:220
enter marks:56 78 98 54
name		roll_number		marks		total_marks
jaya		201		[78, 76, 56, 78]		288
anju		202		[98, 76, 54, 43]		271
likki		203		[65, 34, 35, 67]		201
subbu		204		[45, 67, 89, 65]		266
nanii		205		[67, 87, 89, 76]		319
keerthi		206		[43, 25, 67, 89]		224
poori		207		[78, 76, 65, 90]		309
janu		208		[67, 89, 54, 43]		253
navya		209		[56, 78, 43, 76]		253
kavya		210		[89, 76, 34, 21]		220
kanna		211		[56, 56, 38, 90]		240
lukky		212		[76, 45, 34, 23]		178
rani		213		[56, 78, 87, 34]		255
pooji		214		[90, 87, 56, 34]		267
swapna		215		[78, 56, 43, 89]		266
uma		216		[56, 78, 45, 23]		202
remo		217		[67, 54, 43, 78]		242
ramya		218		[68, 98, 65, 43]		274
lithu		219		[98, 76, 45, 90]		309
divya		220		[56, 78, 98, 54]		286
number of student: 20

student_highest_marks
name: nanii
roll_number: 205
marks: [67, 87, 89, 76]
total_marks: 319

student_lowest_marks
name: lukky
roll_number: 212
marks: [76, 45, 34, 23]
total_marks: 178
[25, 34, 45, 54, 56, 56, 67, 76, 76, 76, 76, 76, 78, 78, 78, 78, 87, 87, 89, 98]

subject_wise_highest_marks:
subject 1 : 98
subject 2 : 98
subject 3 : 98
subject 4 : 90
nanii
nanii 205 [67, 87, 89, 76]
sorted name
anju
divya
janu
jaya
kanna
kavya
keerthi
likki
lithu
lukky
nanii
navya
pooji
poori
ramya
rani
remo
subbu
swapna
uma
